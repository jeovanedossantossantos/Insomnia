import styled from 'styled-components'

export const Button = styled.button`

    margin-right: 5px;
`
