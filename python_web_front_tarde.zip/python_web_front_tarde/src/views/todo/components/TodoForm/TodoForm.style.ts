import styled from "styled-components";

export const PaddingBottom = styled.div`


    padding-bottom: 60px;
`